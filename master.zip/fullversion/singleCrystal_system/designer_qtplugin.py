print("Loading SOL Widgets")
from sol_widgets.widgets.qtplugins import *